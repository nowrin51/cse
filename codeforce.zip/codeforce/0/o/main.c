#include <stdio.h>
#include <stdlib.h>

int main()
{
char a,s,b,x;
scanf ("%c%c%c",&a,&s,&b);
x = a*s*b;
printf ("%c\n",x);

return 0;
}
