#include <stdio.h>
#include <stdlib.h>

int main()
{
int a,b,x;
char s;
scanf ("%d%c%d",&a,&s,&b);
switch (s)
{
case '+':
    x = a + b;
    printf ("%d\n",x);
    break;
case  '-':
    x = a - b;
    printf ("%d\n",x);
    break;
case '*':
    x = a * b;
    printf ("%d\n",x);
    break;
case '/':
    x = a / b;
    printf ("%d\n",x);
    break;
}
return 0;
}
