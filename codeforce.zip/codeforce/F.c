#include <stdio.h>
int main()
{
    long long int N,M,X;
    scanf ("%lld%lld",&N,&M);
    X = (N%10)+(M%10);
    printf ("%lld\n",X);
    return 0;
}
