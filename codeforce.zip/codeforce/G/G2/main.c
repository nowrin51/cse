#include <stdio.h>
#include <stdlib.h>

int main()
{
double n,s=0;
scanf ("%lf",&n);
s = s +(n * ((n + 1)/2));
printf ("%.0lf\n",s);
return 0;
}
