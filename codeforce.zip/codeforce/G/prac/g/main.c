#include <stdio.h>
#include <stdlib.h>

int main()
{
long long int n,x;
scanf ("%lld",&n);
x = (n * (n + 1))/2;
printf ("%lld\n",x);
return 0;
}

