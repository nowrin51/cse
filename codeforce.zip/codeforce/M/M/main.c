#include <stdio.h>
#include <stdlib.h>

int main()
{
char x;
scanf ("%c",&x);
if (x>='A' && x<='Z')
{
    printf ("ALPHA\nIS CAPITAL\n",x);
}
else if (x>='a' && x<='z')
{
    printf ("ALPHA\nIS SMALL\n",x);
}
else
{
    printf ("IS DIGIT\n",x);
}
return 0;
}


