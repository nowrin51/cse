#include <stdio.h>
#include <stdlib.h>

int main()
{
long long int n,i;
scanf ("%lld",&n);
for (i=1;i<=n;i++)
{
    if (i%2==0)
    {
    printf ("%lld\n",i);
    }
}
if (n<2)
    printf ("-1\n");

return 0;
}
