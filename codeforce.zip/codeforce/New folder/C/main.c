
#include <stdio.h>
#include <stdlib.h>

int main()
{
long long int x,n,even=0,odd=0,pos=0,neg=0;
scanf ("%d",&x);
while (x--)
{
    scanf ("%lld",&n);
    if (n%2==0)
    even++;

    else
     odd++;

    if (n>0)
        pos++;

    if(n<0)
        neg++;
}
     printf ("Even: %lld\n",even);
     printf ("Odd: %lld\n",odd);
     printf ("Positive: %lld\n",pos);
     printf ("Negative: %lld\n",neg);

return 0;
}
