#include <stdio.h>
#include <stdlib.h>

int main()
{
long long int n;
while (1)
{
    scanf ("%lld",&n);
    if (n==1999)
    {
        printf ("Correct\n",n);
        break;
    }
    if (n!=1990)
    {
        printf ("Wrong\n",n);
    }
}
return 0;
}


