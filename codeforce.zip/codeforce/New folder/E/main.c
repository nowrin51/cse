#include <stdio.h>
#include <stdlib.h>

int main()
{
int x,n,max=-1;
scanf ("%d",&n);
while (n--)
{
    scanf ("%d",&x);
    if (x>max)
        max = x;
}
printf ("%d\n",max);
return 0;
}
