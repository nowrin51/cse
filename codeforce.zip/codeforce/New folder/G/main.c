#include <stdio.h>
#include <stdlib.h>

int main()
{
int i,n,a,fact=1,sum=0;
scanf ("%d",&n);
while (n--)
{
    fact = 1;
    scanf ("%d",&a);
    for (i=1;i<=a;i++)
    {
    fact = fact * i;
    }
printf ("%d\n",fact);
}

return 0;
}
