#include <stdio.h>
#include <stdlib.h>

int main()
{
long long int num;
scanf ("%lld",&num);
int temp=num,ans=0,r;
while (temp>0)
{
    r = temp % 10;
    ans = (ans * 10) + r;
    temp = temp / 10;
}
if (num==ans)
    printf ("%lld\nYES\n",ans);
else
    printf ("%lld\nNO\n",ans);
return 0;
}
