#include <stdio.h>
#include <stdlib.h>

int main()
{
 int x;
scanf ("%d",&x);
long long int num;
while (x--)
       {
           scanf ("%lld",&num);
           long long int temp=num,ans=0,r;
           while (temp>0)
           {
           r = temp % 10;
          ans =(ans * 10) + r;
          temp = temp / 10;
           }

     printf ("%lld\n",ans);
       }

     return 0;
}
