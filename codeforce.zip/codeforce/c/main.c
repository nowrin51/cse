#include <stdio.h>

int main()
{
long long int X,Y,Z;
scanf ("%lld%lld",&X,&Y);
Z = X + Y;
printf ("%lld + %lld = %lld\n",X,Y,Z);
Z = X * Y;
printf ("%lld * %lld = %lld\n",X,Y,Z);
Z = X - Y;
printf ("%lld - %lld = %lld\n",X,Y,Z);
return 0;
}
