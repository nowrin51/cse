#include <iostream>
#include <string>
#include <stack>
#include <unordered_map>
std::string is_balanced(const std::string& s) {
    std::unordered_map<char, int> chars = {
        {'(', -1},
        {')', 1},
        {'[', -2},
        {']', 2},
        {'{', -3},
        {'}', 3},
    };
}
    std::stack<int> openingParentheses;
    for (char bracket : s) {
        if (chars[bracket] < 0) {
            openingParentheses.push(chars[bracket]);
        }
        else if (chars[bracket] > 0) {
            if (openingParentheses.empty()) {
                return "NO";
            }
            int top = openingParentheses.top();
            openingParentheses.pop();
            if (chars[top] + chars[bracket] != 0) {
                return "NO";
        }
    }
    return openingParentheses.empty() ? "YES" : "NO";
}

int main() {
    std::string input = "(a + [b + c])";
    std::cout << "Input: " << input << std::endl;
    std::cout << "Is balanced? " << is_balanced(input) << std::endl;
    input = "{a + [b + c])}";
    std::cout << "Input: " << input << std::endl;
    std::cout << "Is balanced? " << is_balanced(input) << std::endl;
return0;
}
