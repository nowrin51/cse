#include <iostream>
#include <string>
#include <stack>
#include <unordered_map>

std::string is_balanced(const std::string& s) {
    std::unordered_map<char, int> chars = {
        {'(', -1}, {')', 1},
        {'[', -2}, {']', 2},
        {'{', -3}, {'}', 3}
    };

    std::stack<char> stack;

    for (char bracket : s) {
        if (chars.find(bracket) != chars.end()) {
            if (chars[bracket] < 0) {
                stack.push(bracket);
            } else {
                if (stack.empty()) {
                    return "NO";
                }
                char top = stack.top();
                stack.pop();
                if (chars[top] + chars[bracket] != 0) {
                    return "NO";
                }
            }
        }
    }

    return stack.empty() ? "YES" : "NO";
}

int main() {
    // Test cases
    std::cout << is_balanced("()") << std::endl;        // Output: "YES"
    std::cout << is_balanced("()[]{}") << std::endl;    // Output: "YES"
    std::cout << is_balanced("(]") << std::endl;        // Output: "NO"
    std::cout << is_balanced("([)]") << std::endl;      // Output: "NO"

    return 0;
}
