/*#include <bits/stdc++.h>
using namespace std;
int main() {
    int n;
    cin>>n;
    unordered_set<string,int> arr;
    for (int i = 0; i < n; ++i) {
        string name;
        cin >> name;

        if (arr.count(name) == 0) {
            arr.insert(name);
            cout << "OK" << endl;
        }
        else {
                arr[name]++;
            cout << name << arr[name]<<endl;
;
        }
    }

    return 0;
}

*/
#include <bits/stdc++.h>
using namespace std;
int main() {
    int n;
    std::cin >> n;

    std::unordered_map<std::string, int> arr;

    for (int i = 0; i < n; ++i) {
        std::string name;
        std::cin >> name;

        if (arr.count(name) == 0) {
            arr[name] = 0;
            std::cout << "OK" << std::endl;
        } else {
            arr[name]++;
            std::cout << name << arr[name] << std::endl;
        }
    }

    return 0;
}
