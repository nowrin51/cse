#include <bits/stdc++.h>
using namespace std;
int main() {
    string url;
    getline(cin, url);
    size_t paramsStart = url.find('?');
    string params = url.substr(paramsStart + 1);
    stringstream ss(params);
    string param, value;
    vector<pair<string, string>> parameters;

    while (getline(ss, param, '=') && getline(ss, value, '&')) {
        parameters.push_back({param, value});
    }
    for (const auto &paramValue : parameters) {
        cout << paramValue.first << ": " << paramValue.second << endl;
    }
    return 0;
}

