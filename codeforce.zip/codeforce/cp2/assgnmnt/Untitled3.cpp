#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

int main() {
    int t;
    cin >> t;

    while (t--) {
        int n;
        cin >> n;

        vector<long long> powers(n);
        for (int i = 0; i < n; ++i) {
            cin >> powers[i];
        }

        vector<long long> dp(n + 1, 0);
        for (int i = 1; i <= n; ++i) {
            dp[i] = max(dp[i], dp[i - 1] + powers[i - 1]);
            if (i >= 2) {
                dp[i] = max(dp[i], dp[i - 2] + powers[i - 1] + powers[i - 2]);
            }
            if (i >= 3) {
                dp[i] = max(dp[i], dp[i - 3] + powers[i - 1] + powers[i - 2] + powers[i - 3]);
            }
        }

        cout << dp[n] << endl;
    }

    return 0;
}
