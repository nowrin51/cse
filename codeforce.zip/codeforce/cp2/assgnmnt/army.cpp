#include <bits/stdc++.h>
using namespace std;

int main() {
    int n;
    cin >> n;
    vector<int> y(n - 1);
    for (int &x : y) {
        cin >> x;
    }
    int a, b;
    cin >> a >> b;
    int year = 0;
    for (int i = a; i < b; i++)
        {
            year += y[i - 1];
        }
    cout << year << endl;
    return 0;
}
