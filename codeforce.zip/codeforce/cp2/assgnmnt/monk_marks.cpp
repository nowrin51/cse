#include <bits/stdc++.h>

using namespace std;

int main() {
    int n;
    cin >> n;

    string name[n];
    int mark[n];

    for (int i = 0; i < n; i++) {
        cin >> name[i] >> mark[i];
    }

    for (int i = 0; i < n; ++i) {
        for (int j = i + 1; j < n; ++j) {
            if (mark[j] > mark[i] || (mark[j] == mark[i] && name[j] < name[i])) {
                swap(mark[i], mark[j]);
                swap(name[i], name[j]);
            }
        }
    }

    for (int i = 0; i < n; i++) {
        cout << name[i] << " " << mark[i] << endl;
    }

    return 0;
}


