#include <bits/stdc++.h>
using namespace std;
int main()
{
    int t;
    cin >> t;

    while (t--) {
        string s;
        cin >> s;

        vector<int> length;
        int c=0;

        for (auto x : s) {
            if (x=='1') {
                c++;
            }
            else
             {
                if (c > 0) {
                    length.push_back(c);
                }
                c = 0;
            }
        }

        if (c > 0) {
            length.push_back(c);
        }

        sort(length.rbegin(), length.rend());  //for decending order

        int sum = 0;
        for (int i = 0; i < length.size(); i += 2)
            {
            sum += length[i];
            }

        cout << sum << endl;
    }

    return 0;
}


