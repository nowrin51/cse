#include <iostream>

using namespace std;

int main() {
    int n, k;
    cin >> n >> k;

    int arr[n];
    for (int i = 0; i < n; ++i) {
        cin >> arr[i];
    }

    for (int i = 0; i < k; ++i) {
        int q;
        cin >> q;

        int left = 0;
        int right = n;
        int maxIndex = -1;

        while (left < right) {
            int mid = left + (right - left) / 2;

            if (arr[mid] <= q) {
                maxIndex = mid;
                left = mid + 1;
            } else {
                right = mid;
            }
        }

        if (maxIndex == -1) {
            cout << "0" << endl;
        } else {
            cout << maxIndex + 1 << endl;
        }
    }

    return 0;
}

