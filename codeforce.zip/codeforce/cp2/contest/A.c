#include <iostream>
#include <stack>

using namespace std;

class QueueUsingStacks {
private:
    stack<int> stack_enqueue;
    stack<int> stack_dequeue;

public:
    void enqueue(int value) {
        stack_enqueue.push(value);
    }

    void dequeue() {
        if (stack_dequeue.empty()) {
            while (!stack_enqueue.empty()) {
                stack_dequeue.push(stack_enqueue.top());
                stack_enqueue.pop();
            }
        }
        stack_dequeue.pop();
    }

    int front() {
        if (stack_dequeue.empty()) {
            while (!stack_enqueue.empty()) {
                stack_dequeue.push(stack_enqueue.top());
                stack_enqueue.pop();
            }
        }
        return stack_dequeue.top();
    }
};

int main() {
    int n;
    cin >> n;
    QueueUsingStacks queue;

    for (int i = 0; i < n; ++i) {
        int query;
        cin >> query;

        if (query == 1) {
            int x;
            cin >> x;
            queue.enqueue(x);
        } else if (query == 2) {
            queue.dequeue();
        } else if (query == 3) {
            cout << queue.front() << endl;
        }
    }

    return 0;
}
