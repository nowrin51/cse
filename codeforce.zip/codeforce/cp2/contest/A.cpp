
#include <iostream>
#include <vector>
#include <unordered_set>

using namespace std;

int maxSocksOnTable(int n, const vector<int>& socksOrder) {
    unordered_set<int> table;
    int maxSocks = 0;

    for (int i = 0; i < 2 * n; ++i) {
        int sock = socksOrder[i];
        if (table.count(sock) == 0) {
            table.insert(sock);
            maxSocks = max(maxSocks, static_cast<int>(table.size()));
        } else {
            table.erase(sock);
        }
    }

    return maxSocks;
}

int main() {
    int n;
    cin >> n;

    vector<int> socksOrder(2 * n);
    for (int i = 0; i < 2 * n; ++i) {
        cin >> socksOrder[i];
    }

    int result = maxSocksOnTable(n, socksOrder);
    cout << result << endl;

    return 0;
}
