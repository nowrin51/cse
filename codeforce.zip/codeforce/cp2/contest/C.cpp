#include <iostream>
#include <algorithm>
#include <vector>

using namespace std;

int maxSumAfterSwaps(int n, int k, vector<int>& a, vector<int>& b) {
    int max_sum = 0;

    for (int s = 0; s <= k; s++) {
        vector<int> sorted_a = a;
        vector<int> sorted_b = b;

        sort(sorted_a.begin(), sorted_a.end());
        sort(sorted_b.rbegin(), sorted_b.rend());

        for (int i = 0; i < s; i++) {
            if (sorted_a[i] < sorted_b[i]) {
                swap(sorted_a[i], sorted_b[i]);
            }
        }

        int sum = 0;
        for (int i = 0; i < n; ++i) {
            sum += sorted_a[i];
        }

        max_sum = max(max_sum, sum);
    }

    return max_sum;
}

int main() {
    int t;
    cin >> t;

    while (t--) {
        int n, k;
        cin >> n >> k;

        vector<int> a(n);
        vector<int> b(n);

        for (int i = 0; i < n; i++) {
            cin >> a[i];
        }

        for (int i = 0; i < n; i++) {
            cin >> b[i];
        }

        int result = maxSumAfterSwaps(n, k, a, b);
        cout << result << endl;
    }

    return 0;
}
