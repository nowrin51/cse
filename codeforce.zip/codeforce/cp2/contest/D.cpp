#include <iostream>
#include <vector>
#include <unordered_map>
#include <algorithm>

int max_minimum_distance(int n, const std::vector<int>& fillings) {
    std::unordered_map<int, int> last_index;
    int max_min_distance = 0;

    for (int i = 0; i < n; ++i) {
        int filling = fillings[i];
        if (last_index.find(filling) != last_index.end()) {
            int distance = i - last_index[filling];
            max_min_distance = std::max(max_min_distance, distance);
        }
        last_index[filling] = i;
    }

    return max_min_distance;
}

int main() {
    int T;
    std::cin >> T;

    for (int t = 0; t < T; ++t) {
        int n;
        std::cin >> n;

        std::vector<int> fillings(n);
        for (int i = 0; i < n; ++i) {
            std::cin >> fillings[i];
        }

        int result = max_minimum_distance(n, fillings);
        std::cout << result << std::endl;
    }

    return 0;
}

