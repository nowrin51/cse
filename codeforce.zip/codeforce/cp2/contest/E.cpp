#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

int minTotalCost(vector<int>& num) {
    sort(num.begin(), num.end());

    int n = num.size();
    int totalCost = 0;

    while (n > 1) {
        int sum = num[0] + num[1];
        totalCost += sum;
        num.erase(num.begin());
        num[0] = sum;
        n--;
    }

    return totalCost;
}

int main() {
    while (true) {
        int n;
        cin >> n;

        if (n == 0) {
            break;
        }

        vector<int> num(n);

        for (int i = 0; i < n; i++) {
            cin >> num[i];
        }

        int result = minTotalCost(num);
        cout << result << endl;
    }


}
