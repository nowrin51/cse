#include <iostream>
#include <stack>

using namespace std;

class QueueUsingStacks {
private:
    stack<int> inputStack;
    stack<int> outputStack;

public:

    void enqueue(int x) {
        inputStack.push(x);
    }


    int dequeue() {

        if (outputStack.empty()) {
            while (!inputStack.empty()) {
                outputStack.push(inputStack.top());
                inputStack.pop();
            }
        }


        if (outputStack.empty()) {
            cerr << "Queue is empty." << endl;
            return -1;
        }

        int frontElement = outputStack.top();
        outputStack.pop();
        return frontElement;
    }


    int front() {

        if (outputStack.empty()) {
            while (!inputStack.empty()) {
                outputStack.push(inputStack.top());
                inputStack.pop();
            }
        }


        if (outputStack.empty()) {
            cerr << "Queue is empty." << endl;
            return -1;
        }

        return outputStack.top();
    }
};

int main() {
    int q, query, value;
    cin >> q;

    QueueUsingStacks queue;

    while (q--) {
        cin >> query;

        switch (query) {
            case 1:
                cin >> value;
                queue.enqueue(value);
                break;
            case 2:
                queue.dequeue();
                break;
            case 3:
                cout << queue.front() << endl;
                break;
            default:
                cout << "Invalid query type." << endl;
        }
    }

}�

