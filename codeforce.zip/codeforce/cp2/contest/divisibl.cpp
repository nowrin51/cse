#include <bits/stdc++.h>
using namespace std;

int main() {
    int T;
    cin >> T;

    for (int n = 1; n <= T; n++) {
        long long int a, b;
        cin >> a >> b;

        cout << "Case " << n<< ": ";

        long long int c = a%b;

        if (c == 0) {
            cout << "divisible";
        } else {
            cout << "not divisible";
        }

        cout << endl;
    }

    return 0;
}
