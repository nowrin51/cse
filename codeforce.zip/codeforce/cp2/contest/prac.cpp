#include <bits/stdc++.h>
using namespace std;
int main()
{
 /*   int n;
    cin>>n;
    vector <int>arr(n);

     for (auto &x : arr)
     {
         cin>> x;

        cout << x <<" ";
     }*/
     string s;
     getline(cin,s);
     //s = "abc abc";
     cout << s << endl;
     for (auto &x : s)
        cout << x <<endl;
}

