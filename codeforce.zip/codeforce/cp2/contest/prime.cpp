#include <bits/stdc++.h>
using namespace std;

int main() {
    std::string n;
    while (std::getline(std::cin, n)) {
        int sum = 0;

        for (char x : n) {
            if ('a' <= x && x <= 'z')
            {
                sum += (x - 'a' + 1);
            } else if ('A' <= x && x <= 'Z')
            {
                sum += (x - 'A' + 27);
            }
        }
        bool prime = true;
        if (sum <= 1) {
            prime = false;
        } else {
            for (int i = 2; i*i <= sum; ++i) {
                if (sum % i == 0) {
                    prime = false;
                    break;
                }
            }
        }

        if (prime) {
            std::cout << "It is a prime word." <<std::endl;
        } else {
            std::cout << "It is not a prime word." << std::endl;
        }
    }
    return 0;
}
