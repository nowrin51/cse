#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

int main() {
    int n, k;
    cin >> n;
    vector<int> arr(n);

    for (int i = 0; i < n; ++i) {
        cin >> arr[i];
    }

    sort(arr.begin(), arr.end());

    cin >> k;

    for (int i = 0; i < k; ++i) {
        int l, r;
        cin >> l >> r;

        int left = lower_bound(arr.begin(), arr.end(), l) - arr.begin();
        int right = upper_bound(arr.begin(), arr.end(), r) - arr.begin();

        cout << right - left << endl;
    }

    return 0;
}
