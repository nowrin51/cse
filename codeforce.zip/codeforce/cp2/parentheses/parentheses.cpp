#include <iostream>
#include <string>
#include <unordered_map>
#include <stack>
bool is_balanced(const std::string& s, const std::unordered_map<char, int>& chars) {
    std::stack<char> parentheses_stack;
    for (char c : s) {
        if (chars.find(c) != chars.end()) {
            if (chars.at(c) < 0) {
                parentheses_stack.push(c);
            } else {
                if (parentheses_stack.empty() || chars.at(c) != -chars.at(parentheses_stack.top())) {
                    return false;
                }
                parentheses_stack.pop();
            }
        }
    }
    return parentheses_stack.empty();
}
int main() {
    std::string s = "((abc)def)";
    std::unordered_map<char, int> chars = { {'(', -1}, {')', 1} }; //for "YES" output
   // std::unordered_map<char, int> chars = { {'(', -1}, {'[', 1} }; // for "NO" output
    if (is_balanced(s, chars)) {
        std::cout << "YES" << std::endl;
    } else {
        std::cout << "NO" << std::endl;
    }
    return 0;
}

