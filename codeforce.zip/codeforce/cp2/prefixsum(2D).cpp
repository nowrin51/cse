#include <iostream>

using namespace std;

const int MAX_ROWS = 100; // Maximum number of rows
const int MAX_COLS = 100; // Maximum number of columns

int main() {
    int matrix[MAX_ROWS][MAX_COLS]; // Define the 2D array
    int prefixSum[MAX_ROWS][MAX_COLS]; // Define the prefix sum array
    int rows, cols;

    // Input the number of rows and columns
    cout << "Enter the number of rows: ";
    cin >> rows;
    cout << "Enter the number of columns: ";
    cin >> cols;

    prefixSum[0][0] = matrix[0][0];
    // Input the elements of the matrix
    cout << "Enter the elements of the matrix:" << endl;
    for (int i = 0; i < rows; i++) {
        for (int j = 0; j < cols; j++) {
            cin >> matrix[i][j];

        }
    }

    // Compute the prefix sum
    prefixSum[0][0] = matrix[0][0];
   for (int i = 1; i < rows; i++) {
        prefixSum[i][0] = prefixSum[i - 1][0] + matrix[i][0];
    }
    for (int j = 1; j < cols; j++) {
        prefixSum[0][j] = prefixSum[0][j - 1] + matrix[0][j];
    }
    for (int i = 1; i < rows; i++) {
        for (int j = 1; j < cols; j++) {
            prefixSum[i][j] = matrix[i][j] + prefixSum[i - 1][j] + prefixSum[i][j - 1] - prefixSum[i - 1][j - 1];

        }
    }


    // Output the prefix sum matrix

    cout << "Prefix Sum Matrix:" << endl;
    for (int i = 0; i < rows; i++) {
        for (int j = 0; j < cols; j++) {
            cout << prefixSum[i][j] << " ";
        }

    }


    return 0;
}
