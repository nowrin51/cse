
#include <iostream>
#include <string>
#include <stack>
#include <unordered_map>

std::string is_balanced(const std::string& s) {
    // Define the mapping of parentheses characters and their corresponding values
    std::unordered_map<char, int> chars = {
        {'(', -1},
        {')', 1},
        {'[', -2},
        {']', 2},
        {'{', -3},
        {'}', 3},
    };

    // Initialize an empty stack to keep track of opening parentheses
    std::stack<int> stack;

    // Iterate through each character in the input string
    for (char c : s) {
        // Check if the character is a parenthesis
        if (chars.find(c) != chars.end()) {
            // If it's an opening parenthesis, push its corresponding value onto the stack
            if (chars[c] < 0) {
                stack.push(chars[c]);
            }
            // If it's a closing parenthesis, pop the stack and check if it matches the corresponding value
            else {
                // If the stack is empty or the top element doesn't match, the parentheses are unbalanced
                if (stack.empty() || stack.top() != -chars[c]) {
                    return "NO";
                }
                stack.pop();
            }
        }
    }

    // If the stack is empty at the end, all parentheses are balanced
    return stack.empty() ? "YES" : "NO";
}

int main() {
    // Example usage:
    std::cout << is_balanced("(a + b)") << std::endl;  // Output: "YES"
    std::cout << is_balanced("((a + b)") << std::endl;  // Output: "NO"
    std::cout << is_balanced("a + b)") << std::endl;  // Output: "NO"
    std::cout << is_balanced("a + b") << std::endl;  // Output: "YES"

����return�0;
}
