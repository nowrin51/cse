#include <bits/stdc++.h>
using namespace std;
int main()
{
    int arr[]={5,1,2,7,1,9,7};
    int size = sizeof(arr)/sizeof(arr[0]);
    int max =*max_element(arr,arr+size);
    int min=*min_element(arr,arr+size);
    cout << max << " "<< min;

}
