#include <bits/stdc++.h>
using namespace std;
int main() {
    int m;
    cout << "enter the value of m" << endl;
    cin>>m;
    int arr[m];
    cout<< "enter the array values ";
    for (int i=0;i<m;i++)
        cin>> arr[i];
    sort(arr,arr+m);
    cout << "after sorted the array" << endl;
    for (int i=0;i<m;i++)
        cout<< arr[i] << " ";
    cout << endl;
    int n = sizeof(arr) / sizeof(arr[0]);
    int target;
    cout << "enter the value which i search ";
    cin>>target;
    int left = 0;
    int right = n;
    while (left < right) {
        int mid = left + (right - left) / 2;
        if (arr[mid] <= target) {
            left = mid + 1;
        } else {
            right = mid;
        }
    }
    int position = left;
    cout << "The upper bound of " << target << " is at position " << position << endl;
    return 0;
}
