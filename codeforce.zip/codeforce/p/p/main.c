#include <stdio.h>
#include <stdlib.h>

int main()
{
long long int n[100],s;
scanf ("%lld",&n);
s = n / 10;
s = s / 10;
if (s%10==0)
    printf ("%lld EVEN\n");
else
    printf ("%lld ODD\n");
return 0;
}
