#include <stdio.h>
#include <stdlib.h>

int main()
{
long long int n;
scanf ("%lld",&n);
while (n>=10)

    n = n/10;
if (n%2==0)
    printf ("EVEN\n");
else
    printf ("ODD\n");

    return 0;
}

