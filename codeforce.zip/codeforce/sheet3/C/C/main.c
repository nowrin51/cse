#include <stdio.h>
#include <stdlib.h>

int main()
{
int i,n;
scanf ("%d",&n);
int arr[n];
for (i=0;i<n;i++)
{
    scanf ("%d",&arr[i]);
    if (arr[i]>0)
    {
        arr[i] = 1;
        printf ("%d ",arr[i]);
    }
    else if (arr[i]<0)
    {
        arr[i] = 2;
        printf ("%d ",arr[i]);
    }
    else
    {
        printf ("%d ",arr[i]);
    }
}
return 0;
}


